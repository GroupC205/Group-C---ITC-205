package bcccp.tickets.adhoc;
import java.text.SimpleDateFormat;

public class AdhocTicketFactory implements IAdhocTicketFactory {

	@Override
	public IAdhocTicket make(String carparkId, int ticketNo) {

		long dateTime = System.currentTimeMillis();

		SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");

		String barcode =  Integer.toString(ticketNo) + formatter.format(dateTime);


		AdhocTicket newTicket = new AdhocTicket(carparkId, ticketNo, barcode);
		newTicket.enter(dateTime);

		return newTicket;   
	}

}
