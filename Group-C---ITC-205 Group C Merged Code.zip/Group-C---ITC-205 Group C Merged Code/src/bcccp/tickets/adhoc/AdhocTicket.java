package bcccp.tickets.adhoc;

public class AdhocTicket implements IAdhocTicket {

	private String carparkId;
	private int ticketNo;
	private long entryDateTime = 0;
	private long paidDateTime = 0;
	private long exitDateTime = 0;
	private float charge = 0;
	private String barcode;

	public AdhocTicket(String carparkId, int ticketNo, String barcode) {
		this.carparkId = carparkId;
		this.ticketNo = ticketNo;
		this.barcode = barcode;

	}


	@Override
	public int getTicketNo() {
		return ticketNo;
	}

	@Override
	public String getBarcode() {
		return barcode;
	}

	@Override
	public String getCarparkId() {
		return carparkId;
	}

	@Override
	public void enter(long dateTime) {
		this.entryDateTime = dateTime;		
	}


	@Override
	public long getEntryDateTime() {
		return entryDateTime;
	}

	@Override
	public boolean isCurrent() {
		return entryDateTime != 0 && exitDateTime == 0;
	}


	@Override
	public void pay(long dateTime, float charge) {
		this.charge = charge;
		this.paidDateTime = dateTime;	
	}


	@Override
	public long getPaidDateTime() {
		return paidDateTime;
	}

	@Override

	public boolean isPaid() {
		long currentMilli = System.currentTimeMillis() - getPaidDateTime();
		long fifteenMinutes = 900000;
		return (paidDateTime != 0) && (currentMilli <= fifteenMinutes);

	}


	@Override
	public float getCharge() {
		return charge;
	}

	@Override
	public void exit(long dateTime) {
		this.exitDateTime = dateTime;

	}

	@Override
	public long getExitDateTime() {
		return exitDateTime;
	}

	@Override
	public boolean hasExited() {
		return exitDateTime != 0;
	}



}
